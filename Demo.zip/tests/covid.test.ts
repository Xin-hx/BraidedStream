/**
 * COVID dataset loader tests (real file, METHOD.md M11).
 */
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import path from "node:path";
import { describe, expect, it } from "vitest";
import { parseCovidCsv } from "../code/covid";
import censusRegions from "../code/dataset/us-census-regions.json";
import { runPipeline } from "../code/index";
import type { CorridorOptions } from "../code/types";

const csvPath = path.join(
  path.dirname(fileURLToPath(import.meta.url)),
  "..",
  "code",
  "dataset",
  "ensemble_covid_inc_case.csv"
);

describe("covid loader", () => {
  const text = readFileSync(csvPath, "utf-8");
  const { layers, times } = parseCovidCsv(text);

  it("aggregates all states into the four Census regions", () => {
    expect(layers.map((l) => l.id)).toEqual(["Northeast", "Midwest", "South", "West"]);
    expect(times.length).toBeGreaterThan(100);
    for (const layer of layers) {
      for (const key of ["p025", "p10", "p25", "p50", "p75", "p90", "p975"] as const) {
        expect(layer.q[key].length).toBe(times.length);
      }
      // Regional cells may be missing before pipeline interpolation.
      expect(layer.q.p50.every((v) => Number.isFinite(v) || Number.isNaN(v))).toBe(true);
    }
  });

  it("runs the full pipeline on covid data", () => {
    const opts: CorridorOptions = {
      participationThreshold: 0.3,
      amplitudeMax: 0,
      clearance: 0,
      frequencyMin: 0.5,
      frequencyMax: 4,
      windowSmooth: 5,
      budgetEta: 1.6,
      phaseMode: "sine",
    };
    const r = runPipeline(layers, { corridors: opts });
    expect(r.validation.ok).toBe(true);
    const n = r.braided.yTopStar.length;
    const tLen = r.braided.yTopStar[0].length;
    // thickness preserved
    for (let i = 0; i < n; i += 1) {
      for (let t = 0; t < tLen; t += 1) {
        const m = r.base.yTop[i][t] - r.base.yBottom[i][t];
        const mStar = r.braided.yTopStar[i][t] - r.braided.yBottomStar[i][t];
        expect(Math.abs(mStar - m)).toBeLessThan(1e-9);
      }
    }
    // budget respected
    for (let t = 0; t < tLen; t += 1) {
      const h0 = r.base.yTop[n - 1][t] - r.base.baseline[t];
      expect(r.braided.totalHeight[t]).toBeLessThanOrEqual(1.6 * h0 + 1e-6 * Math.max(1, h0));
    }
  });
});
  it("maintains a Census-region mapping for all 50 states and DC", () => {
    expect(Object.keys(censusRegions.states)).toHaveLength(51);
  });
