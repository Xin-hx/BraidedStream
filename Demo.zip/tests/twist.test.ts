import { describe, expect, it } from "vitest";
import type { BaseLayout } from "../code/types";
import {
  buildTwistGeometry,
  foldCreases,
  numericalCrossSectionMean,
  twistG,
  twistPhase,
  twistStrength,
} from "../code/twist";

describe("thickness-preserving pseudo-3D inward fold", () => {
  it("implements G(xi, theta) exactly and remains finite/bounded", () => {
    expect(twistG(0, 0)).toBeCloseTo(-1 / 3);
    expect(twistG(1, 0)).toBeCloseTo(2 / 3);
    expect(twistG(1, Math.PI / 2)).toBeCloseTo(1);
    for (const theta of [0, 0.7, Math.PI / 2, Math.PI, 5.2]) {
      for (let xi = -1; xi <= 1; xi += 0.01) {
        const value = twistG(xi, theta);
        expect(Number.isFinite(value)).toBe(true);
        expect(Math.abs(value)).toBeLessThanOrEqual(5 / 3);
      }
    }
  });

  it("has numerical zero-mean cross sections across representative phases", () => {
    for (const theta of [0, 0.4, Math.PI / 2, Math.PI, 4.7]) {
      expect(Math.abs(numericalCrossSectionMean(theta))).toBeLessThan(1e-6);
    }
  });

  it("maps uncertainty monotonically to fold strength only", () => {
    const strengths = [0, 0.2, 0.5, 0.8, 1].map((u) => twistStrength(u));
    expect(strengths).toEqual([...strengths].sort((a, b) => a - b));
    expect(strengths[0]).toBe(0);
    expect(strengths.at(-1)).toBeLessThan(1);
    expect(twistPhase(20, 120, 2)).toBe(twistPhase(20, 120, 2));
  });

  it("preserves the original outer geometry and only contracts an inner ribbon", () => {
    const base: BaseLayout = {
      baseline: [0, 0],
      yBottom: [[0, 1], [4, 5]],
      yTop: [[4, 5], [10, 13]],
    };
    const geometry = buildTwistGeometry(base, [[0, 1], [0.5, 0.75]]);
    expect(geometry.outerBottom).toEqual(base.yBottom);
    expect(geometry.outerTop).toEqual(base.yTop);
    expect(geometry.outerBottom).not.toBe(base.yBottom);
    for (let i = 0; i < base.yBottom.length; i += 1) {
      for (let t = 0; t < base.baseline.length; t += 1) {
        expect(geometry.outerTop[i][t] - geometry.outerBottom[i][t])
          .toBe(base.yTop[i][t] - base.yBottom[i][t]);
        expect(geometry.innerBottom[i][t]).toBeGreaterThanOrEqual(base.yBottom[i][t]);
        expect(geometry.innerTop[i][t]).toBeLessThanOrEqual(base.yTop[i][t]);
      }
    }
  });

  it("places fold creases exactly at cos(phase)=0 crossings", () => {
    const tLen = 120;
    const layer = 0; // offset 0 → phase(t) = 2π·2.25·t/119
    const uRow = new Array<number>(tLen).fill(0.6);
    const creases = foldCreases(tLen, layer, uRow);
    expect(creases.length).toBeGreaterThanOrEqual(2);
    expect(creases.length).toBeLessThanOrEqual(6);
    for (const c of creases) {
      expect(c.t).toBeGreaterThanOrEqual(0);
      expect(c.t).toBeLessThanOrEqual(tLen - 1);
      expect(Math.abs(Math.cos(twistPhase(c.t, tLen, layer)))).toBeLessThan(0.05);
      expect(c.direction === 1 || c.direction === -1).toBe(true);
      expect(c.strength).toBeGreaterThan(0);
      expect(c.strength).toBeLessThan(1);
    }
    // layer 0 first two creases: φ=π/2 (sin>0 → +1), φ=3π/2 (sin<0 → -1)
    expect(creases[0].t).toBeCloseTo(119 / (4 * 2.25), 1);
    expect(creases[0].direction).toBe(1);
    expect(creases[1].t).toBeCloseTo((3 * 119) / (4 * 2.25), 1);
    expect(creases[1].direction).toBe(-1);
  });

  it("is deterministic and independent of layer thickness", () => {
    const tLen = 60;
    const uRow = Array.from({ length: tLen }, (_, t) => 0.3 + 0.5 * Math.sin(t / 9));
    const a = foldCreases(tLen, 3, uRow);
    const b = foldCreases(tLen, 3, uRow);
    expect(a).toEqual(b);
    // identical phase row with a different u baseline keeps crease positions
    const flat = new Array<number>(tLen).fill(0.4);
    const c = foldCreases(tLen, 3, flat);
    expect(c.map((x) => x.t)).toEqual(a.map((x) => x.t));
  });

  it("scales crease strength monotonically with uncertainty", () => {
    const tLen = 120;
    const low = new Array<number>(tLen).fill(0.15);
    const high = new Array<number>(tLen).fill(0.85);
    const a = foldCreases(tLen, 1, low);
    const b = foldCreases(tLen, 1, high);
    expect(a.length).toBe(b.length);
    for (let i = 0; i < a.length; i += 1) {
      expect(b[i].strength).toBeGreaterThan(a[i].strength);
      expect(b[i].t).toBe(a[i].t);
      expect(b[i].direction).toBe(a[i].direction);
    }
  });
});
