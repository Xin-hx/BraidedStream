import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import path from "node:path";
import { runPipeline } from "../code/index";
import { parseTcmCsv } from "../code/tcm";

describe("TCM CSV loader", () => {
  it("turns each expert class into a layer with median dose across patients per visit", () => {
    const visits = JSON.stringify([{ date: "2024-01-02", categories: { "class a": 10, "class b": 5 } }, { date: "2024-01-04", categories: { "class a": 20 } }]).replaceAll('"', '""');
    const data = parseTcmCsv(`patient_id,categorized_prescriptions_json\n"001","${visits}"`);
    expect(data.times).toEqual(["visit 1", "visit 2"]);
    expect(data.layers.find((layer) => layer.id === "class a")?.q.p50).toEqual([10, 20]);
    expect(data.layers.find((layer) => layer.id === "class b")?.q.p10).toEqual([5, 0]);
  });

  it("loads the bundled patient dataset", () => {
    const text = readFileSync(path.join(process.cwd(), "public", "dataset", "TCMRecord.csv"), "utf8");
    const data = parseTcmCsv(text);
    expect(data.layers).toHaveLength(25);
    expect(data.times.length).toBeGreaterThan(1);
    const result = runPipeline(data.layers, {
      baselineMode: "wiggle",
      corridors: { participationThreshold: 0.3, amplitudeMax: 1, clearance: 0.1, frequencyMin: 0.5, frequencyMax: 4, windowSmooth: 30, budgetEta: 1.6 },
    });
    expect(result.validation.ok).toBe(true);
  });
});
