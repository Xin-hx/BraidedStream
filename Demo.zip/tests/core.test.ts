/**
 * Core pipeline tests: thickness preservation, no collision, budget,
 * determinism, degenerate data, PID semantics.
 */
import { describe, expect, it } from "vitest";
import { runPipeline } from "../code/index";
import { generateSynthetic, mulberry32, normalQuantile } from "../code/synthetic";
import type { CorridorOptions, Layer } from "../code/types";

const TOL = 1e-9;

function defaultOptions(over: Partial<CorridorOptions> = {}): CorridorOptions {
  return {
    participationThreshold: 0.3,
    amplitudeMax: 0,
    clearance: 0,
    gamma: 1,
    encoding: "both",
    frequencyMin: 0.5,
    frequencyMax: 4,
    windowSmooth: 5,
    budgetEta: 1.6,
    phaseMode: "sine",
    ...over,
  };
}

const synth = generateSynthetic({ seed: 42 });

describe("synthetic generator", () => {
  it("is bit-reproducible for a fixed seed", () => {
    const a = generateSynthetic({ seed: 7 });
    const b = generateSynthetic({ seed: 7 });
    expect(a.layers).toEqual(b.layers);
    const c = generateSynthetic({ seed: 8 });
    expect(a.layers).not.toEqual(c.layers);
  });

  it("produces strictly monotone, positive quantiles", () => {
    for (const layer of synth.layers) {
      for (let t = 0; t < layer.q.p50.length; t += 1) {
        const vals = [layer.q.p025[t], layer.q.p10[t], layer.q.p25[t], layer.q.p50[t], layer.q.p75[t], layer.q.p90[t], layer.q.p975[t]];
        for (let k = 1; k < vals.length; k += 1) {
          expect(vals[k]).toBeGreaterThanOrEqual(vals[k - 1] - TOL);
          expect(vals[k - 1]).toBeGreaterThan(0);
        }
      }
    }
  });

  it("has the four Gate-A truth types", () => {
    const ids = synth.layers.map((l) => l.id);
    expect(ids.slice(0, 4)).toEqual(["c0", "c1", "c2", "c3"]); // consensus cluster
    expect(ids).toContain("c4"); // wide coverage
    expect(ids).toContain("c5"); // persistent outlier
    expect(ids).toContain("c6"); // transient deviation
    expect(ids).toContain("c8"); // thin layer, high uncertainty
  });

  it("c8 is thin yet highly uncertain in [50,80] (breaks thick⇔uncertain)", () => {
    const c8 = synth.layers.find((l) => l.id === "c8")!;
    const c0 = synth.layers.find((l) => l.id === "c0")!;
    const mean = (a: number[]) => a.reduce((x, y) => x + y, 0) / a.length;
    // thin: q50 of c8 is a small fraction of c0's
    expect(mean(c8.q.p50)).toBeLessThan(0.35 * mean(c0.q.p50));
    // uncertain: its 80% PI is wider than c0's in the spike window
    const w = (l: Layer) =>
      l.q.p90.slice(50, 81).map((v, i) => v - l.q.p10[50 + i]);
    expect(mean(w(c8))).toBeGreaterThan(mean(w(c0)));
  });

  it("mulberry32 and normalQuantile are sane", () => {
    const r = mulberry32(1);
    const xs = [r(), r(), r()];
    expect(xs.every((x) => x >= 0 && x < 1)).toBe(true);
    expect(normalQuantile(0.5)).toBeCloseTo(0, 5);
    expect(normalQuantile(0.975)).toBeGreaterThan(1.9);
    expect(normalQuantile(0.025)).toBeLessThan(-1.9);
  });
});

describe("braided pipeline", () => {
  const opts = defaultOptions();
  const result = runPipeline(synth.layers, { corridors: opts });

  it("passes validation", () => {
    expect(result.validation.ok).toBe(true);
  });

  it("keeps layer thickness exactly: U* - L* = m", () => {
    const n = result.braided.yTopStar.length;
    const tLen = result.braided.yTopStar[0].length;
    for (let i = 0; i < n; i += 1) {
      for (let t = 0; t < tLen; t += 1) {
        const m = result.base.yTop[i][t] - result.base.yBottom[i][t];
        const mStar = result.braided.yTopStar[i][t] - result.braided.yBottomStar[i][t];
        expect(Math.abs(mStar - m)).toBeLessThan(TOL);
      }
    }
  });

  it("respects the budget: H*(t) <= eta * H0(t) + tol", () => {
    const tLen = result.braided.totalHeight.length;
    for (let t = 0; t < tLen; t += 1) {
      const h0 = result.base.yTop[result.base.yTop.length - 1][t] - result.base.baseline[t];
      const budget = opts.budgetEta * h0;
      expect(result.braided.totalHeight[t]).toBeLessThanOrEqual(budget + 1e-6 * Math.max(1, budget));
    }
  });

  it("has no envelope collisions: gap >= 0", () => {
    const n = result.braided.envelopeHigh.length;
    const tLen = result.braided.envelopeHigh[0].length;
    for (let i = 0; i + 1 < n; i += 1) {
      for (let t = 0; t < tLen; t += 1) {
        const gap = result.braided.envelopeLow[i + 1][t] - result.braided.envelopeHigh[i][t];
        expect(gap).toBeGreaterThanOrEqual(-1e-6);
      }
    }
    expect(result.costs.collisionCount).toBe(0);
  });

  it("has u in [0,1] and width >= 0", () => {
    for (const row of result.uncertainty.u) {
      for (const v of row) {
        expect(v).toBeGreaterThanOrEqual(0);
        expect(v).toBeLessThanOrEqual(1);
      }
    }
    for (const row of result.uncertainty.width) {
      for (const v of row) expect(v).toBeGreaterThanOrEqual(0);
    }
  });

  it("keeps phase continuous (integrated phase definition)", () => {
    expect(result.costs.phaseContinuityMax).toBeLessThan(1e-9);
  });

  it("never allocates more than requested", () => {
    expect(result.costs.allocRatio).toBeLessThanOrEqual(1 + 1e-9);
    const n = result.corridors.aReq.length;
    const tLen = result.corridors.aReq[0].length;
    for (let i = 0; i < n; i += 1) {
      for (let t = 0; t < tLen; t += 1) {
        expect(result.braided.aAlloc[i][t]).toBeLessThanOrEqual(result.corridors.aReq[i][t] + TOL);
      }
    }
  });

  it("reports requested > allocated under a tight budget", () => {
    const tight = runPipeline(synth.layers, { corridors: defaultOptions({ budgetEta: 1.001 }) });
    expect(tight.costs.allocRatio).toBeLessThan(0.999);
    expect(tight.costs.requestedTotal).toBeGreaterThan(tight.costs.allocatedTotal);
  });

  it("is deterministic across runs", () => {
    const a = runPipeline(synth.layers, { corridors: opts });
    const b = runPipeline(synth.layers, { corridors: opts });
    expect(a.braided.yTopStar).toEqual(b.braided.yTopStar);
    expect(a.costs).toEqual(b.costs);
  });

  it("orders PID: consensus cluster deeper than outliers, deepest in center", () => {
    const pid = result.pid;
    const c0 = pid.depth["c0"];
    const c5 = pid.depth["c5"];
    const c6 = pid.depth["c6"];
    expect(c0).toBeGreaterThan(c5);
    expect(c0).toBeGreaterThan(c6);
    // deepest layers sit near the center; at least one of the two central
    // slots is a consensus-cluster layer (c0..c3), and the persistent
    // outlier c5 is the shallowest
    const order = pid.order;
    const mid = Math.floor(order.length / 2);
    const centerIds = order.slice(mid - 1, mid + 1);
    expect(centerIds.some((id) => ["c0", "c1", "c2", "c3"].includes(id))).toBe(true);
    expect(pid.depth["c5"]).toBeLessThan(pid.depth["c1"]);
  });

  it("expansion is vertically symmetric: per-time mean displacement ≈ 0", () => {
    const r = runPipeline(synth.layers, {
      corridors: defaultOptions({ participationThreshold: 0.95 }),
    });
    const n = r.braided.s.length;
    const tLen = r.braided.s[0].length;
    for (let t = 0; t < tLen; t += 1) {
      let mean = 0;
      for (let i = 0; i < n; i += 1) mean += r.braided.s[i][t];
      expect(Math.abs(mean / n)).toBeLessThan(1e-9);
    }
  });

  it("sine baseline (SineStream Gaussian L2) is valid end-to-end", () => {
    const r = runPipeline(synth.layers, {
      corridors: defaultOptions(),
      baselineMode: "sine",
    });
    expect(r.validation.ok).toBe(true);
    const n = r.braided.yTopStar.length;
    const tLen = r.braided.yTopStar[0].length;
    for (let i = 0; i < n; i += 1) {
      for (let t = 0; t < tLen; t += 1) {
        const m = r.base.yTop[i][t] - r.base.yBottom[i][t];
        const mStar = r.braided.yTopStar[i][t] - r.braided.yBottomStar[i][t];
        expect(Math.abs(mStar - m)).toBeLessThan(TOL);
      }
    }
    // budget + no collision still hold
    for (let t = 0; t < tLen; t += 1) {
      const h0 = r.base.yTop[n - 1][t] - r.base.baseline[t];
      expect(r.braided.totalHeight[t]).toBeLessThanOrEqual(1.6 * h0 + 1e-6 * Math.max(1, h0));
    }
    expect(r.costs.collisionCount).toBe(0);
    // sine differs from wiggle geometry
    const wig = runPipeline(synth.layers, { corridors: defaultOptions() });
    expect(r.base.baseline).not.toEqual(wig.base.baseline);
  });

  it("handles degenerate data: q50 ≈ 0 layers produce no NaN/Inf", () => {
    const layers = synth.layers.map((l) => {
      const scale = 1e-9;
      const q = Object.fromEntries(
        (Object.entries(l.q) as [string, number[]][]).map(([k, v]) => [k, v.map((x) => x * scale)])
      ) as unknown as typeof l.q;
      return { id: l.id, q };
    });
    const r = runPipeline(layers, { corridors: defaultOptions() });
    for (const row of r.uncertainty.u) for (const v of row) expect(Number.isFinite(v)).toBe(true);
    for (const row of r.braided.yTopStar) for (const v of row) expect(Number.isFinite(v)).toBe(true);
    expect(r.costs.collisionCount).toBeGreaterThanOrEqual(0);
  });

  it("L2 phase optimization is deterministic and collision-free", () => {
    const optsL2 = defaultOptions({ phaseMode: "l2", l2Rounds: 3, l2GridPoints: 17 });
    const a = runPipeline(synth.layers, { corridors: optsL2 });
    const b = runPipeline(synth.layers, { corridors: optsL2 });
    expect(a.phases.phi).toEqual(b.phases.phi);
    expect(a.braided.yTopStar).toEqual(b.braided.yTopStar);
    const n = a.braided.envelopeHigh.length;
    const tLen = a.braided.envelopeHigh[0].length;
    for (let i = 0; i + 1 < n; i += 1) {
      for (let t = 0; t < tLen; t += 1) {
        const gap = a.braided.envelopeLow[i + 1][t] - a.braided.envelopeHigh[i][t];
        expect(gap).toBeGreaterThanOrEqual(-1e-6);
      }
    }
  });

  it("phase mode cannot change explicit-seam geometry", () => {
    const sine = runPipeline(synth.layers, { corridors: defaultOptions({ phaseMode: "sine" }) });
    const l2 = runPipeline(synth.layers, { corridors: defaultOptions({ phaseMode: "l2" }) });
    expect(sine.braided.seam).toEqual(l2.braided.seam);
    expect(sine.braided.yTopStar).toEqual(l2.braided.yTopStar);
    expect(sine.braided.o.every((row) => row.every((value) => value === 0))).toBe(true);
  });
});
