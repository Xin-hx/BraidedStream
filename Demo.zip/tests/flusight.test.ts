/**
 * FluSight influenza hospital-admission dataset tests (real file).
 * Source: Datasets/FluSight-forecast-hub -> scripts/extract-flusight.mjs
 * -> code/dataset/ensemble_flusight_hosp.csv (wk inc flu hosp, horizon 1).
 */
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import path from "node:path";
import { describe, expect, it } from "vitest";
import { parseCovidCsv } from "../code/covid";
import { runPipeline } from "../code/index";
import type { CorridorOptions } from "../code/types";

const csvPath = path.join(
  path.dirname(fileURLToPath(import.meta.url)),
  "..",
  "code",
  "dataset",
  "ensemble_flusight_hosp.csv"
);

describe("flusight loader", () => {
  const text = readFileSync(csvPath, "utf-8");
  const { layers, times } = parseCovidCsv(text);

  it("aggregates all states into the four Census regions", () => {
    expect(layers.map((l) => l.id)).toEqual(["Northeast", "Midwest", "South", "West"]);
    expect(times.length).toBeGreaterThanOrEqual(80);
    for (const layer of layers) {
      for (const key of ["p025", "p10", "p25", "p50", "p75", "p90", "p975"] as const) {
        expect(layer.q[key].length).toBe(times.length);
        expect(layer.q[key].every((v) => Number.isFinite(v))).toBe(true);
      }
    }
  });

  it("runs the full pipeline on flusight data", () => {
    const opts: CorridorOptions = {
      participationThreshold: 0.3,
      amplitudeMax: 0,
      clearance: 0,
      frequencyMin: 0.5,
      frequencyMax: 4,
      windowSmooth: 5,
      budgetEta: 1.6,
      phaseMode: "sine",
    };
    const r = runPipeline(layers, { corridors: opts });
    expect(r.validation.ok).toBe(true);
    const n = r.braided.yTopStar.length;
    const tLen = r.braided.yTopStar[0].length;
    for (let i = 0; i < n; i += 1) {
      for (let t = 0; t < tLen; t += 1) {
        const m = r.base.yTop[i][t] - r.base.yBottom[i][t];
        const mStar = r.braided.yTopStar[i][t] - r.braided.yBottomStar[i][t];
        expect(Math.abs(mStar - m)).toBeLessThan(1e-9);
      }
    }
    for (let t = 0; t < tLen; t += 1) {
      const h0 = r.base.yTop[n - 1][t] - r.base.baseline[t];
      expect(r.braided.totalHeight[t]).toBeLessThanOrEqual(1.6 * h0 + 1e-6 * Math.max(1, h0));
    }
  });
});
