import { describe, expect, it } from "vitest";
import { parseEditableCsv } from "../code/editable";

const header = "time,layer,p025,p10,p25,p50,p75,p90,p975";
const row = (time: string, layer: string, start: number) => `${time},${layer},${[0, 1, 2, 3, 4, 5, 6].map((n) => start + n).join(",")}`;

describe("editable CSV loader", () => {
  it("keeps file order and requires a complete layer-time grid", () => {
    const data = parseEditableCsv([header, row("t0", "a", 1), row("t0", "b", 10), row("t1", "a", 2), row("t1", "b", 11)].join("\n"));
    expect(data.times).toEqual(["t0", "t1"]);
    expect(data.layers.map((layer) => layer.id)).toEqual(["a", "b"]);
    expect(data.layers[0].q.p50).toEqual([4, 5]);
    expect(() => parseEditableCsv([header, row("t0", "a", 1), row("t1", "b", 10)].join("\n"))).toThrow("missing layer");
    expect(() => parseEditableCsv([header, "t0,a,1,2,3,2,5,6,7"].join("\n"))).toThrow("invalid");
  });
});
