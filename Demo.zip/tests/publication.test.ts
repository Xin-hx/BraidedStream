import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { runPipeline } from "../code/index";
import { computeUncertainty } from "../code/uncertainty";
import { eventGate } from "../code/corridors";
import { generateSynthetic } from "../code/synthetic";
import {
  publicationCalmRegions,
  publicationEventAttributes,
  selectPublicationEvents,
} from "../code/publication";
import type { CorridorOptions, Layer, QuantileMatrix } from "../code/types";

function layerWithWidths(id: string, widths: number[]): Layer {
  const q = {
    p025: [], p10: [], p25: [], p50: [], p75: [], p90: [], p975: [],
  } as QuantileMatrix;
  for (const width of widths) {
    q.p025.push(10 - width / 2 - 1);
    q.p10.push(10 - width / 2);
    q.p25.push(10 - width / 4);
    q.p50.push(10);
    q.p75.push(10 + width / 4);
    q.p90.push(10 + width / 2);
    q.p975.push(10 + width / 2 + 1);
  }
  return { id, q };
}

function corridorOptions(over: Partial<CorridorOptions> = {}): CorridorOptions {
  return {
    participationThreshold: 0,
    amplitudeMax: 10,
    clearance: 0.1,
    gamma: 1,
    encoding: "both",
    frequencyMin: 0.5,
    frequencyMax: 4,
    windowSmooth: 0,
    budgetEta: 3,
    phaseMode: "sine",
    ...over,
  };
}

describe("publication contract: shared calibration", () => {
  it("maps equal raw widths anywhere to equal default u and unbudgeted request", () => {
    const layers = [
      layerWithWidths("a", [4, 2, 8]),
      layerWithWidths("b", [1, 4, 2]),
    ];

    const uncertainty = computeUncertainty(layers, { smoothWindow: 0 });
    expect(uncertainty.width[0][0]).toBe(uncertainty.width[1][1]);
    expect(uncertainty.u[0][0]).toBeCloseTo(uncertainty.u[1][1], 12);

    const result = runPipeline(layers, {
      smoothWindow: 0,
      corridors: corridorOptions(),
    });
    const aStack = result.pid.order.indexOf("a");
    const bStack = result.pid.order.indexOf("b");
    expect(result.corridors.aReq[aStack][0]).toBeCloseTo(
      result.corridors.aReq[bStack][1],
      12
    );
  });
});

describe("publication contract: exact closed state", () => {
  it("uses a C2 compact gate at both exact endpoints", () => {
    expect(eventGate(0.3, 0.3, 0.6)).toBe(0);
    expect(eventGate(0.6, 0.3, 0.6)).toBe(1);
    // A cubic smoothstep is about 0.00326 here; the quintic C2 gate stays
    // below 0.001 and avoids a visible second-derivative shoulder.
    expect(eventGate(0.31, 0.3, 0.6)).toBeLessThan(0.001);
    expect(1 - eventGate(0.59, 0.3, 0.6)).toBeLessThan(0.001);
  });

  it("uses one compact gate for amplitude, clearance, and displayed seam", () => {
    const layers = [
      layerWithWidths("a", [0, 1, 3, 4, 10, 4, 3, 1, 0]),
      layerWithWidths("b", [0, 0, 0, 0, 0, 0, 0, 0, 0]),
    ];
    const options = {
      ...corridorOptions({ windowSmooth: 5 }),
      eventCloseThreshold: 0.3,
      eventOpenThreshold: 0.5,
    } as CorridorOptions;
    const result = runPipeline(layers, { smoothWindow: 0, corridors: options });
    const corridors = result.corridors as typeof result.corridors & {
      gate: number[][];
      seamReq: number[][];
    };
    const braided = result.braided as typeof result.braided & { seam: number[][] };
    const aStack = result.pid.order.indexOf("a");
    const bStack = result.pid.order.indexOf("b");
    const seamIndex = Math.min(aStack, bStack);

    expect(corridors.gate[aStack][0]).toBe(0);
    expect(corridors.gate[aStack][2]).toBe(0);
    expect(corridors.gate[aStack][3]).toBeGreaterThan(0);
    expect(corridors.gate[aStack][3]).toBeLessThan(1);
    expect(corridors.gate[aStack][4]).toBe(1);
    expect(corridors.aReq[aStack][0]).toBe(0);
    expect(corridors.seamReq[seamIndex][0]).toBe(0);
    expect(Math.abs(braided.seam[seamIndex][0])).toBeLessThan(1e-9);
    expect(braided.seam[seamIndex][4]).toBeGreaterThan(0);
  });
});

describe("publication contract: separation and rejoining truth", () => {
  it("has staggered compact seam events while preserving all geometry invariants", () => {
    const { layers } = generateSynthetic({ seed: 20260811 });
    const options = corridorOptions({
      participationThreshold: 0.3,
      eventOpenThreshold: 0.45,
      windowSmooth: 15,
      budgetEta: 1.6,
    });
    const a = runPipeline(layers, { smoothWindow: 0, corridors: options });
    const b = runPipeline(layers, { smoothWindow: 0, corridors: options });
    const windows: { seam: number; start: number; peak: number; end: number; height: number }[] = [];

    for (let seam = 0; seam < a.braided.seam.length; seam += 1) {
      const row = a.braided.seam[seam];
      let start = -1;
      for (let t = 0; t <= row.length; t += 1) {
        const active = t < row.length && row[t] > 1e-12;
        if (active && start < 0) start = t;
        if (!active && start >= 0) {
          let peak = start;
          for (let k = start + 1; k < t; k += 1) if (row[k] > row[peak]) peak = k;
          windows.push({ seam, start, peak, end: t - 1, height: row[peak] });
          start = -1;
        }
      }
    }

    const separatedPeaks = [...windows]
      .sort((x, y) => y.height - x.height)
      .filter((event, index, picked) =>
        picked.slice(0, index).every((other) => Math.abs(other.peak - event.peak) >= 18)
      );
    expect(separatedPeaks.length).toBeGreaterThanOrEqual(2);
    for (const event of separatedPeaks.slice(0, 2)) {
      const row = a.braided.seam[event.seam];
      expect(event.start).toBeGreaterThan(0);
      expect(event.end).toBeLessThan(row.length - 1);
      expect(row[event.start - 1]).toBe(0);
      expect(row[event.end + 1]).toBe(0);
      expect(row[event.peak]).toBeGreaterThan(0);
      const maxJump = Math.max(...row.slice(1).map((value, t) => Math.abs(value - row[t])));
      expect(maxJump).toBeLessThan(0.5 * event.height);
    }

    for (let i = 0; i < a.braided.yTopStar.length; i += 1) {
      for (let t = 0; t < a.braided.yTopStar[i].length; t += 1) {
        expect(a.braided.yTopStar[i][t] - a.braided.yBottomStar[i][t])
          .toBeCloseTo(a.base.yTop[i][t] - a.base.yBottom[i][t], 12);
      }
    }
    for (const row of a.braided.seam) for (const gap of row) expect(gap).toBeGreaterThanOrEqual(0);
    expect(a.costs.maxHeightRatio).toBeLessThanOrEqual(options.budgetEta + 1e-9);
    expect(a.braided.seam).toEqual(b.braided.seam);
    expect(a.braided.yTopStar).toEqual(b.braided.yTopStar);
  });
});

describe("publication presentation model", () => {
  it("selects two or three local windows with stable DOM hooks and calm ends", () => {
    const { layers } = generateSynthetic({ seed: 20260811 });
    const result = runPipeline(layers, {
      smoothWindow: 0,
      corridors: corridorOptions({
        participationThreshold: 0.3,
        eventOpenThreshold: 0.45,
        budgetEta: 1.6,
      }),
    });
    const events = selectPublicationEvents(result.braided.seam);
    const calm = publicationCalmRegions(result.braided.seam);

    expect(events.length).toBeGreaterThanOrEqual(2);
    expect(events.length).toBeLessThanOrEqual(3);
    expect(events.map((event) => event.peak)).toEqual(
      [...events].sort((a, b) => a.peak - b.peak).map((event) => event.peak)
    );
    for (const event of events) {
      expect(publicationEventAttributes(event)).toMatchObject({
        "data-event-annotation": "true",
        "data-event-start": String(event.start),
        "data-event-peak": String(event.peak),
        "data-event-end": String(event.end),
      });
    }
    expect(calm).toHaveLength(2);
    expect(calm[0]).toMatchObject({ edge: "start", start: 0 });
    expect(calm[1]).toMatchObject({ edge: "end", end: result.braided.seam[0].length - 1 });
  });

  it("wires DOM-testable publication, annotation, and calm-region hooks", () => {
    const html = readFileSync(new URL("../index.html", import.meta.url), "utf8");
    const main = readFileSync(new URL("../demo/main.ts", import.meta.url), "utf8");
    const render = readFileSync(new URL("../demo/render.ts", import.meta.url), "utf8");
    const css = readFileSync(new URL("../demo/style.css", import.meta.url), "utf8");

    expect(html).toContain('data-presentation="publication"');
    expect(html).toContain('id="btn-publication"');
    expect(html).toContain('id="btn-diagnostic"');
    expect(main).toContain('presentation: "publication"');
    expect(render).toContain('"data-presentation-mode"');
    expect(render).toContain("publicationEventAttributes");
    expect(render).toContain('"data-calm-region"');
    expect(render).toContain("prepareExportClone");
    expect(render).toContain('class: "corridor-fill"');
    expect(render).toContain('"data-corridor-seam"');
    expect(render).toContain('class: "calm-bracket"');
    expect(render).toContain('class: "event-centerline"');
    expect(render).toContain("time (synthetic index)");
    expect(render).toContain('class: "svg-encoding-key"');
    expect(render).toContain("median q50");

    expect(render).toContain("circles = open, peak, rejoin");
    expect(render).toContain("not missing data");
    expect(render).toContain('input.presentation === "publication" ? 6 : 10');
    expect(render).toContain("selected adjacent-layer separation–rejoining intervals");
    expect(render).toContain("layer identities");
    expect(render).toContain("font:600 15px sans-serif");
    expect(main).toContain("A–C = selected opening");
    expect(main).toContain("dashed outline = collapsed Σq50");
    expect(main).toContain("data-layer-legend");
    expect(main).toContain("thin / high-u");
    expect(css).toContain('body[data-presentation="publication"] .panel');
    expect(css).toContain('body[data-presentation="publication"] .costs');
    expect(css).toContain("#chart .corridor-fill");
    expect(css).toContain("#chart .calm-bracket");
  });
});
