import { describe, expect, it } from "vitest";
import {
  GLARE_ALPHA,
  GLARE_CARRIER_WIDTH_PX,
  GLARE_THRESHOLD,
  detectGlareSources,
  glareKernel,
  screenChannel,
} from "../code/glare";

describe("parameter-adapted Zhou glare approximation", () => {
  const centers = [
    Array.from({ length: 8 }, (_, x) => ({ x, y: 20 })),
    Array.from({ length: 8 }, (_, x) => ({ x, y: 80 })),
  ];

  it("detects one local maximum per above-threshold region", () => {
    const u = [
      [0.1, 0.4, 0.7, 0.6, 0.2, 0.41, 0.9, 0.2],
      [0.1, 0.39, 0.2, 0.1, 0.2, 0.3, 0.1, 0.2],
    ];
    expect(GLARE_THRESHOLD).toBe(0.4);
    expect(detectGlareSources(u, centers).map((source) => [source.layer, source.time, source.strength]))
      .toEqual([[0, 2, 0.7], [0, 6, 0.9]]);
  });

  it("is deterministic and keeps carrier width independent of layer height", () => {
    const u = [[0.2, 0.8, 0.3]];
    const thin = [[{ x: 0, y: 10 }, { x: 1, y: 10 }, { x: 2, y: 10 }]];
    const thick = [[{ x: 0, y: 50 }, { x: 1, y: 50 }, { x: 2, y: 50 }]];
    const a = detectGlareSources(u, thin);
    const b = detectGlareSources(u, thin);
    const c = detectGlareSources(u, thick);
    expect(a).toEqual(b);
    expect(a[0].carrierWidthPx).toBe(GLARE_CARRIER_WIDTH_PX);
    expect(c[0].carrierWidthPx).toBe(GLARE_CARRIER_WIDTH_PX);
  });

  it("has a deterministic, non-negative, center-dominant composite kernel", () => {
    const center = glareKernel(0, 0, 3);
    expect(center).toEqual(glareKernel(0, 0, 3));
    for (const point of [[1, 2], [9, 0], [15, 4], [30, 20]] as const) {
      const sample = glareKernel(point[0], point[1], 3);
      expect(Object.values(sample).every((value) => Number.isFinite(value) && value >= 0)).toBe(true);
      expect(center.total).toBeGreaterThan(sample.total);
    }
  });

  it("uses bounded screen-style composition at alpha 0.60", () => {
    expect(GLARE_ALPHA).toBe(0.6);
    expect(screenChannel(0.25, 0)).toBe(0.25);
    expect(screenChannel(0.25, 1)).toBeCloseTo(0.7);
    expect(screenChannel(0.9, 10)).toBe(1);
  });
});
