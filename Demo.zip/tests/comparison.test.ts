import { describe, expect, it } from "vitest";
import {
  ROUTE_A_HEIGHT,
  ROUTE_A_SEED,
  ROUTE_A_WIDTH,
  createRouteAComparison,
} from "../code/comparison";

describe("Route-A comparison contract", () => {
  it("recreates one locked base fixture for every page", () => {
    const a = createRouteAComparison();
    const b = createRouteAComparison();

    expect(ROUTE_A_SEED).toBe(20260811);
    expect([ROUTE_A_WIDTH, ROUTE_A_HEIGHT]).toEqual([560, 300]);
    expect(a.times).toEqual(b.times);
    expect(a.result.pid.order).toEqual(b.result.pid.order);
    expect(a.result.base).toEqual(b.result.base);
    expect(a.result.uncertainty.u).toEqual(b.result.uncertainty.u);
    expect(a.colors).toEqual(b.colors);
    expect(a.yDomain).toEqual(b.yDomain);
    expect(a.times).toHaveLength(120);
  });
});
